##========= History =========

Version 6.x support S-Cart 6.x

Version 7.x support S-Cart 7.x

Link plugin: https://s-cart.org/en/plugin/vnpay-basic_15925770111eeccbf3bbe41.html
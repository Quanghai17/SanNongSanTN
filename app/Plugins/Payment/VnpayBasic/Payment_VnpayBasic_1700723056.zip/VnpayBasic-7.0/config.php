<?php 
return [
    'vnpay_secretKey' => env('vnpay_secretKey', ''),
    'vnpay_partnerCode' => env('vnpay_partnerCode', ''),
    'vnpay_urlApi' => env('vnpay_urlApi', ''),
];
========= History =========

Version 5.x support S-Cart 6.x
Version 6.x support S-Cart 7.x

Link plugin: https://s-cart.org/en/plugin/product-review_16084756995fdf643399113.html